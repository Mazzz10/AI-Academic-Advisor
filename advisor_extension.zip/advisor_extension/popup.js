document.getElementById("btn").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const status = document.getElementById("status");

  status.textContent = " جاري السحب...";

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ["scraper.js"]
  }, () => {
    status.textContent = " تم! تحقق من التنزيلات";
  });
});